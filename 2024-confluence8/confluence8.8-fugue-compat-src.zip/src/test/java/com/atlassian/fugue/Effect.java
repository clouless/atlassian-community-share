/*

WE ONLY HAVE THIS HERE UNTIL WE CAN MOCK MacroDefinition WITHOUT CLASS NOT FOUDN ERRORS

 */
package com.atlassian.fugue;

public interface Effect<A> {

    void apply(A a);

    public interface Applicant<A> {
        void foreach(Effect<? super A> effect);
    }
}
