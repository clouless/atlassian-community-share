package com.atlassian.fugue;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.base.Supplier;

import java.io.Serializable;
import java.util.Iterator;
import java.util.NoSuchElementException;

import static com.atlassian.fugue.Option.none;
import static com.atlassian.fugue.Option.some;
import static com.google.common.base.Preconditions.checkNotNull;

public abstract class Either<L, R> implements Serializable {
    private static final long serialVersionUID = -1L;

    public static <L, R> Either<L, R> left(final L left) {
        checkNotNull(left);
        return new Left<L, R>(left);
    }

    public static <L, R> Either<L, R> right(final R right) {
        checkNotNull(right);
        return new Right<L, R>(right);
    }

    @Deprecated public static <T> T merge(final Either<T, T> either) {
        return null;
    }

    @Deprecated public static <L, R> Either<L, R> cond(final boolean predicate, final R right, final L left) {
        return null;
    }

    @Deprecated public static <X extends Exception, A> A getOrThrow(final Either<X, A> either) throws X {
        return null;
    }

    @Deprecated public static <L, R> Either<L, Iterable<R>> sequenceRight(final Iterable<Either<L, R>> eithers) {
        return null;
    }

    @Deprecated public static <L, R> Either<Iterable<L>, R> sequenceLeft(final Iterable<Either<L, R>> eithers) {
        return null;
    }

    Either() {}

    public final LeftProjection left() {
        return new LeftProjection();
    }

    public final RightProjection right() {
        return new RightProjection();
    }

    public final R getOrElse(final Supplier<? extends R> supplier) {
        return right().getOrElse(supplier);
    }

    public final <X extends R> R getOrElse(final X other) {
        return right().getOrElse(other);
    }

    public final R getOrNull() {
        return right().getOrNull();
    }

    public final R getOrError(Supplier<String> msg) {
        return right().getOrError(msg);
    }

    public final <X extends Throwable> R getOrThrow(Supplier<X> ifUndefined) throws X {
        return right().getOrThrow(ifUndefined);
    }

    public final <X> Either<L, X> map(final Function<? super R, X> f) {
        return right().map(f);
    }

    public final <X, LL extends L> Either<L, X> flatMap(final Function<? super R, Either<LL, X>> f) {
        return right().flatMap(f);
    }

    public final boolean exists(final Predicate<? super R> p) {
        return right().exists(p);
    }

    public final boolean forall(final Predicate<? super R> p) {
        return right().forall(p);
    }

    public final void foreach(final Effect<? super R> effect) {
        right().foreach(effect);
    }

    public final Either<L, R> orElse(final Either<? extends L, ? extends R> orElse) {
        return null;
    }

    public final Either<L, R> orElse(final Supplier<? extends Either<? extends L, ? extends R>> orElse) {
        if (right().isDefined()) {
            return new Right<L, R>(right().get());
        }

        @SuppressWarnings("unchecked")
        Either<L, R> result = (Either<L, R>) orElse.get();
        return result;
    }

    public final R valueOr(final Function<L, ? extends R> or) {
        if (right().isDefined()) {
            return right().get();
        }

        return or.apply(left().get());
    }

    public final Option<Either<L, R>> filter(final Predicate<? super R> p) {
        return right().filter(p);
    }

    public final Option<R> toOption() {
        return right().toOption();
    }

    public <X> Either<L, X> sequence(final Either<L, X> e) {
        return right().sequence(e);
    }

    public <X> Either<L, X> apply(final Either<L, Function<R, X>> either) {
        return right().apply(either);
    }

    public final <X> Either<X, R> leftMap(final Function<? super L, X> f) {
        return left().map(f);
    }

    public abstract boolean isLeft();

    public abstract boolean isRight();

    public abstract Either<R, L> swap();

    public abstract <V> V fold(Function<? super L, V> ifLeft, Function<? super R, V> ifRight);

    public abstract <LL, RR> Either<LL, RR> bimap(final Function<? super L, ? extends LL> ifLeft, final Function<? super R, ? extends RR> ifRight);

    L getLeft() {
        throw new NoSuchElementException();
    }

    R getRight() {
        throw new NoSuchElementException();
    }

    static final class Left<L, R> extends Either<L, R> {
        private static final long serialVersionUID = -6846704510630179771L;

        private final L value;

        public Left(final L value) {
            checkNotNull(value);
            this.value = value;
        }

        @Override final L getLeft() {
            return value;
        }

        @Override public boolean isLeft() {
            return true;
        }

        @Override public boolean isRight() {
            return false;
        }

        @Override public Either<R, L> swap() {
            return right(value);
        }

        @Override public <V> V fold(final Function<? super L, V> ifLeft, final Function<? super R, V> ifRight) {
            return ifLeft.apply(value);
        }

        @Override public <LL, RR> Either<LL, RR> bimap(Function<? super L, ? extends LL> ifLeft, Function<? super R, ? extends RR> ifRight) {
            @SuppressWarnings("unchecked")
            final Either<LL, RR> map = (Either<LL, RR>) left().map(ifLeft);
            return map;
        }

        @Override public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if ((o == null) || !(o instanceof Left<?, ?>)) {
                return false;
            }
            return value.equals(((Left<?, ?>) o).value);
        }

        @Override public int hashCode() {
            return ~value.hashCode();
        }

        @Override public String toString() {
            return "Either.Left(" + value.toString() + ")";
        }
    }

    static final class Right<L, R> extends Either<L, R> {
        private static final long serialVersionUID = 5025077305715784930L;

        private final R value;

        public Right(final R value) {
            checkNotNull(value);
            this.value = value;
        }

        @Override final R getRight() {
            return value;
        }

        @Override public boolean isRight() {
            return true;
        }

        @Override public boolean isLeft() {
            return false;
        }

        @Override public Either<R, L> swap() {
            return left(value);
        }

        @Override public <V> V fold(final Function<? super L, V> ifLeft, final Function<? super R, V> ifRight) {
            return ifRight.apply(value);
        }

        @Override public <LL, RR> Either<LL, RR> bimap(Function<? super L, ? extends LL> ifLeft, Function<? super R, ? extends RR> ifRight) {
            @SuppressWarnings("unchecked")
            final Either<LL, RR> map = (Either<LL, RR>) right().map(ifRight);
            return map;
        }

        @Override public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if ((o == null) || !(o instanceof Right<?, ?>)) {
                return false;
            }
            return value.equals(((Right<?, ?>) o).value);
        }

        @Override public int hashCode() {
            return value.hashCode();
        }

        @Override public String toString() {
            return "Either.Right(" + value.toString() + ")";
        }
    }

    abstract class AbstractProjection<A, B> implements Projection<A, B, L, R> {
        @Override public final Iterator<A> iterator() {
            return toOption().iterator();
        }

        @Override public final Either<L, R> either() {
            return Either.this;
        }

        @Override public final boolean isEmpty() {
            return !isDefined();
        }

        @Override public final Option<A> toOption() {
            return isDefined() ? some(get()) : Option.<A> none();
        }

        @Override public final boolean exists(final Predicate<? super A> f) {
            return isDefined() && f.apply(get());
        }

        @Override final public A getOrNull() {
            return isDefined() ? get() : null;
        }

        @Override public final boolean forall(final Predicate<? super A> f) {
            return isEmpty() || f.apply(get());
        }

        @Override public final A getOrError(final Supplier<String> err) {
            return toOption().getOrError(err);
        }

        @Override public <X extends Throwable> A getOrThrow(Supplier<X> ifUndefined) throws X {
            return toOption().getOrThrow(ifUndefined);
        }

        @Override public final A getOrElse(final Supplier<? extends A> a) {
            return isDefined() ? get() : a.get();
        }

        @Override public final <X extends A> A getOrElse(final X x) {
            return isDefined() ? get() : x;
        }

        @Override public final void foreach(final Effect<? super A> f) {
            if (isDefined()) {
                f.apply(get());
            }
        }
    }

    public final class LeftProjection extends AbstractProjection<L, R> implements Projection<L, R, L, R> {
        private LeftProjection() {}

        public L get() {
            return getLeft();
        }

        @Override public boolean isDefined() {
            return isLeft();
        }

        public L on(final Function<? super R, ? extends L> f) {
            return isLeft() ? get() : f.apply(right().get());
        }

        public <X> Either<X, R> map(final Function<? super L, X> f) {
            return isLeft() ? new Left<X, R>(f.apply(get())) : this.<X> toRight();
        }

        public <X, RR extends R> Either<X, R> flatMap(final Function<? super L, Either<X, RR>> f) {
            if (isLeft()) {
                @SuppressWarnings("unchecked")
                Either<X, R> result = (Either<X, R>) f.apply(get());
                return result;
            } else {
                return this.toRight();
            }
        }

        <X> Right<X, R> toRight() {
            return new Right<X, R>(getRight());
        }

        public <X> Either<X, R> sequence(final Either<X, R> e) {
            return null;
        }

        public <X> Option<Either<L, X>> filter(final Predicate<? super L> f) {
            if (isLeft() && f.apply(get())) {
                final Either<L, X> result = new Left<L, X>(get());
                return some(result);
            }
            return none();
        }

        public <X> Either<X, R> apply(final Either<Function<L, X>, R> either) {
            return either.left().flatMap(new Function<Function<L, X>, Either<X, R>>() {
                public Either<X, R> apply(final Function<L, X> f) {
                    return map(f);
                }
            });
        }

        <X> Either<L, X> as() {
            return left(get());
        }
    }

    public final class RightProjection extends AbstractProjection<R, L> implements Projection<R, L, L, R> {
        private RightProjection() {}

        @Override public R get() {
            return getRight();
        }

        @Override public boolean isDefined() {
            return isRight();
        }

        @Override public R on(final Function<? super L, ? extends R> f) {
            return isRight() ? get() : f.apply(left().get());
        }

        public <X> Either<L, X> map(final Function<? super R, X> f) {
            return isRight() ? new Right<L, X>(f.apply(get())) : this.<X> toLeft();
        }

        public <X, LL extends L> Either<L, X> flatMap(final Function<? super R, Either<LL, X>> f) {
            if (isRight()) {
                @SuppressWarnings("unchecked")
                Either<L, X> result = (Either<L, X>) f.apply(get());
                return result;
            } else {
                return this.toLeft();
            }
        }

        <X> Left<L, X> toLeft() {
            return new Left<L, X>(left().get());
        }

        public <X> Either<L, X> sequence(final Either<L, X> e) {
            return null;
        }

        public <X> Option<Either<X, R>> filter(final Predicate<? super R> f) {
            if (isRight() && f.apply(get())) {
                final Either<X, R> result = new Right<X, R>(get());
                return some(result);
            }
            return none();
        }

        public <X> Either<L, X> apply(final Either<L, Function<R, X>> either) {
            return either.right().flatMap(new Function<Function<R, X>, Either<L, X>>() {
                public Either<L, X> apply(final Function<R, X> f) {
                    return map(f);
                }
            });
        }

        <X> Either<X, R> as() {
            return right(get());
        }
    }

    public interface Projection<A, B, L, R> extends Maybe<A> {
        Either<L, R> either();

        Option<? super A> toOption();

        A on(Function<? super B, ? extends A> f);
    }
}