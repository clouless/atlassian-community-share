/*

WE ONLY HAVE THIS HERE UNTIL WE CAN MOCK MacroDefinition WITHOUT CLASS NOT FOUDN ERRORS

 */
package com.atlassian.fugue;

import java.util.Iterator;

import com.google.common.base.Predicate;
import com.google.common.base.Supplier;

public interface Maybe<A> extends Iterable<A>, Effect.Applicant<A> {

    A get();

    <B extends A> A getOrElse(final B other);

    A getOrElse(final Supplier<? extends A> supplier);

    A getOrNull();

    A getOrError(Supplier<String> msg);

    <X extends Throwable> A getOrThrow(Supplier<X> ifUndefined) throws X;

    boolean isDefined();

    boolean isEmpty();

    boolean exists(final Predicate<? super A> p);

    Iterator<A> iterator();

    boolean forall(final Predicate<? super A> p);
}