package com.atlassian.util.concurrent;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.Condition;

public final class Timeout {

    public static Timeout getNanosTimeout(long time, TimeUnit unit) {
        return null;
    }

    public static Timeout getMillisTimeout(long time, TimeUnit unit) {
        return null;
    }

    /*Timeout(long time, TimeUnit unit, com.atlassian.util.concurrent.Timeout.TimeSupplier supplier) {

    }*/

    public long getTime() {
        return 0L;
    }

    public TimeUnit getUnit() {
        return null;
    }

    public boolean isExpired() {
        return this.getTime() <= 0L;
    }

    void await(Awaitable waitable) throws TimeoutException, InterruptedException {
        if (!waitable.await(this.getTime(), this.getUnit())) {
            this.throwTimeoutException();
        }

    }

    void await(Condition condition) throws TimeoutException, InterruptedException {
        if (!condition.await(this.getTime(), this.getUnit())) {
            this.throwTimeoutException();
        }

    }

    public void throwTimeoutException() throws TimedOutException {
        throw new TimedOutException(this.getTime(), this.getUnit());
    }
}