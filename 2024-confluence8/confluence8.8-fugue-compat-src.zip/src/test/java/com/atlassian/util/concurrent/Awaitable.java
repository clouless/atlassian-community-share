package com.atlassian.util.concurrent;

import java.util.concurrent.TimeUnit;

public interface Awaitable {
    void await() throws InterruptedException;

    boolean await(long var1, TimeUnit var3) throws InterruptedException;
}